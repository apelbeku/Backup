# Change Log

## [1.5.0] 2019-12-18
### Updates
- added latest version of Bootstrap `4.4.1`

## [1.4.0] 2019-07-04
### Updates
- added latest version of Bootstrap `4.3.1`

## [1.3.0] 2019-02-08
### Updates, Bugfixing, Improvements
- added latest version of Bootstrap `4.2.1`
- all plugins out of date were updated to the latest version
- `btn-simple` removed
- added `btn-outline` from the bootstrap
- docs updated all plugins versions

## [1.2.0] 2018-10-12
### Bootstrap 4.1.3 update
- `Chart.js` library updated
- Responsive fixes
- Other small bug fixes

## [1.1.0] 2018-05-04
### Bootstrap 4.1.0 update
- Archive cleaned
- Other small bug fixes

## [1.0.1] 2018-02-21
### Bugfixing
- Fixed some issues for documentation pages
- Scss cleaned
- Other bug fixes

## [1.0.0] 2018-02-14
### Original Release
